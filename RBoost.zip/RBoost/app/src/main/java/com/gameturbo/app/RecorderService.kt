package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File

/** Merekam layar (tanpa suara) ke Movies/RBoost. */
class RecorderService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var mp: MediaProjection? = null
    private var rec: MediaRecorder? = null
    private var vd: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (!recording) {
                stopSelf()
            } else {
                finishRec()
            }
            return START_NOT_STICKY
        }
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("data")
        }
        if (data == null || !begin(code, data)) {
            toast("Rekam layar gagal dimulai")
            recording = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_LONG).show()

    private fun startAsForeground() {
        val id = "rboost_rec"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(id, "Rekam layar", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 5, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, id)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("R BOOST merekam layar")
            .setContentText("Ketuk Berhenti untuk menyimpan")
            .setOngoing(true)
            .addAction(0, "Berhenti", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2002, n)
        }
    }

    private fun begin(code: Int, data: Intent): Boolean {
        return try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mgr.getMediaProjection(code, data)
            mp = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post { finishRec() }
                }
            }, handler)

            val size = Sys.realSize(this)
            var w = size.first
            var h = size.second
            val maxEdge = 1280
            val big = if (w > h) w else h
            if (big > maxEdge) {
                val k = maxEdge.toFloat() / big.toFloat()
                w = (w * k).toInt()
                h = (h * k).toInt()
            }
            w = w and 1.inv()
            h = h and 1.inv()

            @Suppress("DEPRECATION")
            val r = MediaRecorder()
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(w, h)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(6_000_000)
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Video.Media.DISPLAY_NAME, Sys.videoName())
                v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/RBoost")
                val uri: Uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return false
                val p = contentResolver.openFileDescriptor(uri, "w") ?: return false
                pfd = p
                r.setOutputFile(p.fileDescriptor)
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                r.setOutputFile(File(dir, Sys.videoName()).absolutePath)
            }
            r.prepare()
            rec = r
            val dpi = resources.displayMetrics.densityDpi
            vd = proj.createVirtualDisplay(
                "rboost", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
            r.start()
            recording = true
            toast("Merekam layar...")
            true
        } catch (e: Exception) {
            cleanup()
            false
        }
    }

    private fun cleanup() {
        try { vd?.release() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        vd = null; rec = null; pfd = null
        val m = mp
        mp = null
        try { m?.stop() } catch (_: Exception) {}
    }

    private fun finishRec() {
        if (stopping) return
        stopping = true
        var saved = false
        try {
            rec?.stop()
            saved = true
        } catch (_: Exception) {
        }
        cleanup()
        recording = false
        if (saved) toast("Rekaman tersimpan di Movies/RBoost")
        stopSelf()
    }

    override fun onDestroy() {
        recording = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.gameturbo.app.STOP_REC"

        @Volatile
        var recording = false
    }
}
