package com.gameturbo.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

object Booster {

    fun memInfo(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    fun ramPercent(ctx: Context): Int {
        val mi = memInfo(ctx)
        if (mi.totalMem <= 0L) return 0
        return (((mi.totalMem - mi.availMem) * 100L) / mi.totalMem).toInt()
    }

    /** Level baterai (0-100) atau -1 kalau tidak terbaca. */
    fun batteryPercent(ctx: Context): Int {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) level * 100 / scale else -1
    }

    fun charging(ctx: Context): Boolean {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val st = bat.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    /** Suhu baterai dalam derajat Celsius, atau null kalau tidak terbaca. */
    fun batteryTempC(ctx: Context): Float? {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        return if (t >= 0) t / 10f else null
    }

    /**
     * Tutup proses background app lain (kecuali launcher, app ini, dan [keep]).
     * Return jumlah app yang diproses.
     */
    fun boost(ctx: Context, keep: Set<String>): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = ctx.packageManager

        val home = pm
            .resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val skip = keep + ctx.packageName + setOfNotNull(home)
        val targets = pm.queryIntentActivities(launcherIntent, 0)
            .map { it.activityInfo.packageName }
            .toSet() - skip

        targets.forEach { am.killBackgroundProcesses(it) }
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        return targets.size
    }
}
